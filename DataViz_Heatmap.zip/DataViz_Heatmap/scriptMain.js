var map = L.map('map').setView(startCoordinates, startZoom);
var xhr;  // Declare the XMLHttpRequest object globally
var markers = [];  // Array to store markers
var heatLayer;  // Heatmap layer
var heatSpots = [];
var lineCoordinates = [];

// ADD TILE LAYER (OpenStreetMap)
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors'
    }).addTo(map);

// ADD CUSTOM ICON FOR MARKERS
var icon = L.icon({
    iconUrl: iconFile,
    iconSize: [30, 30],
    iconAnchor: [15, 30]
    });

// ---- LOAD COORDINATES AND MAKE MARKERS
function loadCoordinates() {
    if (xhr.status === 200) {
        // Clear existing markers
        markers.forEach(function(marker) {
            map.removeLayer(marker);
        });
        markers = [];
        heatSpots = []; // Clear existing heatmap data
        metaTagReq = metaTagReq.toLowerCase(); // force things to lowercase

        var csv = xhr.responseText;
        var data = csv.split('\n');
        var headers = data[0].split(',');
        var nameItem = headers.indexOf('Image_Name');
        var titleName = headers.indexOf('Title');
        var latIndex = headers.indexOf('Latitude');
        var lngIndex = headers.indexOf('Longitude');
        var metaTags = headers.indexOf('Metatags');
        var ratings = headers.indexOf('Ratings');

        for (var i = 1; i < data.length; i++) {
            var row = data[i].split(',');
            if (row.length >= 2) {
                var title = row[titleName];
                var nam = row[nameItem];
                var lat = parseFloat(row[latIndex]);
                var lng = parseFloat(row[lngIndex]);
                var mTags = row[metaTags].toLowerCase();
                var rat = parseFloat(row[ratings]);
                lineCoordinates.push([lat, lng]);
                
                // CHECK IF LAT LONG & METATAGs
                if (!isNaN(lat) && !isNaN(lng) && mTags.includes(metaTagReq)) {
                    // ---------------------
                    // SWITCH ON/OFF HEATMAP 
                    if(layerHeatmap){heatSpots.push([lat, lng, mTags.includes(metaTagReq)]);} 
                    // ---------------------
                    // SWITCH ON/OFF ICON POINTS
                    if (layerPointIcons){
                        markers.push(L.marker([lat, lng], {icon: icon}).addTo(map).bindPopup(
                            // EDIT THE HTML FOR EACH POPUP
                            '<b>' + title + '</b><br>' +
                            '' + mTags + '<br>' +
                            '<div id=popupPhoto style="background-image:URL(./PHOTOS/' +
                            nam +
                            ')"></div>'
                            ));
                    }
                    // ---------------------
                    // SWITCH ON/OFF CIRCLE POINTS
                    if(layerPointCircles){
                        var circle = L.circle([lat, lng], {
                            color: 'red',
                            weight: 0.1,
                            fillColor: 'red',
                            fillOpacity: 0.5,
                            radius: 25,
                            radius: rat*(map.getZoom()*200)
                        }).addTo(map).bindPopup(
                            // EDIT THE HTML FOR EACH POPUP
                            '<b>' + nam + '</b><br>' +
                            '' + mTags + '<br>'
                            );
                    }
                    console.log(map.getZoom());
                }
            }
                    
            // CLEAR ANY HEATLAYERS
            if (heatLayer) { map.removeLayer(heatLayer); }
         
            // CREATE NEW HEATLAYER
            heatLayer = L.heatLayer(heatSpots, {
                radius: 10,
                blur: 15,
                maxZoom: 8,
                opacity: 90,       // Adjust the opacity (0 to 1)
                // gradient: {         // Define gradient colors
                //     0.4: 'red',
                //     0.65: 'lime',
                //     1: 'blue'
                // }
            }).addTo(map);
        }
        // --------------------------
        // EXTRAS, COMMENT THEM ON/OFF
        // SEE scriptExtras.js
        if(layerDrawLines){loadPolyline()};
        if(layerDrawRegion){loadDrawStar()};
    }
}


// ---- REFRESH / REDRAW FUNCTION
function refreshMap() {
	var newMetaTagReq = document.getElementById('metaTagInput').value;
    metaTagReq = newMetaTagReq.toLowerCase();
    
    xhr.open('GET', dataFile);
    xhr.onload = loadCoordinates;
    xhr.send();
}


xhr = new XMLHttpRequest();
xhr.open('GET', dataFile); 		// READ CSV
xhr.onload = loadCoordinates;	// PLACE MARKERS
xhr.send();

