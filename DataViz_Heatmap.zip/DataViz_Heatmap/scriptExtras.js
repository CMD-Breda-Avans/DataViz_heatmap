
function loadPolyline(){
        var polyline = L.polyline(lineCoordinates, { 
            color: 'blue',           // Outline color
            opacity: 0.6,
            fillColor: 'blue',       // Fill color
            fillOpacity: 0.4,        // Light opacity (0 to 1)
            stroke: true,            // Display stroke (border)
            weight: 1,               // Stroke width
        }).addTo(map);
}

function loadDrawStar(){
    let pnts = [    [51.594278, 4.769241], 
                    [51.583, 4.777],
                    [51.594278, 4.785], 
                    [51.588840, 4.769241], 
                    [51.588089, 4.785], 
                    [51.594278, 4.769241]];
    var polygon = L.polygon(pnts, { 
        color: 'blue',           // Outline color
        fillColor: 'blue',       // Fill color
        fillOpacity: 0.3,        // Light opacity (0 to 1)
        stroke: true,            // Display stroke (border)
        weight: 1,               // Stroke width

    }).addTo(map);
}

